import React from "react";
import footer from "../css/footer.css";

function Footer() {
  return (
    <div class="footer">
      <i   class="fa-brands fa-instagram"></i>
      <i   class="fa-brands fa-x-twitter"></i>
      <i   class="fa-brands fa-facebook"></i>
      <p  id="icons">Contact:2345765</p>

    </div>
  );
}

export default Footer;




