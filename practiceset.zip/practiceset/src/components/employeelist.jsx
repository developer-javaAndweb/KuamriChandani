import React from 'react';


const Employees = [
  {
    id: 101,
    name: "riya",
    department: "computer Engineering",
  },

  {
    id: 102,
    name: "Bob",
    department: "IT",
  },

  {
    id: 103,
    name: "Jack",
    department: "HR",
  },
];

export default Employees;