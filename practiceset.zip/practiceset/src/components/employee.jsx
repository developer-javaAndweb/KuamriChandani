import React from "react";
import employee from '../css/employee.css';
// import Employees from "./components/employeelist";

// const employee = [
//   {
//     id: 101,
//     name: "riya",
//     department: "computer Engineering",
//   },

//   {
//     id: 102,
//     name: "Bob",
//     department: "IT",
//   },

//   {
//     id: 103,
//     name: "Jack",
//     department: "HR",
//   },
// ];

// let { Name, Department } = employee;

function Employee(props) {
  return (
    <div class="containers">
      <div class="container">
      <h4>Name:{props.name}</h4>
      <h4>Id:{props.id}</h4>
      <h4>Department:{props.department}</h4>
      <button class="delete" onClick={ () => props.onDelete(props.id)}>Delete</button>
      </div>


      {/* this is the  employee array now receives array from  data through props. */}
      {/* <h1>Employee Details</h1>
    {employee.map((employee) => (
      <div key={employee.id}>
        <h2>{employee.name}</h2>
        <p>{employee.id}</p>
        <p>{employee.department}</p>
        <hr />
      </div>
    ))} */}
    </div>
  );
}

export default Employee;
