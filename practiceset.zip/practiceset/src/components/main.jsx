import react from "react";
function Main() {
  return (
    <div>

        {/* <div>
      <table>

        <thead>
        <tr>
          <th>components</th>
          <th>descriptions</th>
        </tr>
        </thead>


<tbody>
        <tr>
          <td>header</td>
          <td>it is first componets of react that show the heading of page</td>
        </tr>

        <tr>
          <td>main</td>
          <td>It is main components</td>
        </tr>
        <tr>
          <td>footer</td>
          <td>It is footer components</td>
        </tr>
</tbody>

      </table>
    </div> */}
    </div>
  );
}

export default Main;
