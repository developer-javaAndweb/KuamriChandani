import React from "react";
import header from "../css/header.css";


function Header(props) {
  return (
    <div class="title">
      <header>Employee Management</header>
     
    </div>
  );
}

export default Header;
