import React, { useState } from "react";
import Header from "./components/header";
// import Main from "./components/main";
import Footer from "./components/footer";
import Employee from "./components/employee";
import Employees from "./components/employeelist";
import app from "./css/app.css";




function App() {
  const [showEmployees, setShowEmployees] = useState(true);
  const [employees, setEmployees] = useState(Employees);

  const [name, setName] = useState("");
  const [department, setDepartment] = useState("");
  const [id, setId] = useState("");

  function addEmployee() {
    if (id === "" || name.trim() === "" || department.trim() === "") {
      alert("fill all the details");
      return;
    }

    if (employees.some((emp) => emp.id === Number(id))) {
      alert("Employee is alaready exists");
      return;
    }
    const newEmployee = {
      id: Number(id),
      name: name,
      department: department
    };

    setEmployees([...employees, newEmployee]);
    setId("");
    setName("");
    setDepartment("");
  }
  return (
    <div >


      <div class="topheading">
        <Header />
        <div class="header">
          <h4 class="details">Employee Details:</h4>
          <div>
          <label>Employee ID:
            <input type="number" placeholder="Enter Employee ID" value={id} onChange={(e) => setId(e.target.value)} /></label>
          <label>Name:
            <input type="name" placeholder="Enter Employee Name" value={name} onChange={(e) => setName(e.target.value)} /></label>

          <br />
          <label>Department:<input type="text" placeholder="Enter Employee Department" value={department} onChange={(e) => setDepartment(e.target.value)} /></label>

          <br /><button onClick={addEmployee}> Add employee</button>

          <br />
          <button onClick={() => setShowEmployees(!showEmployees)}>
            {showEmployees ? "Hide Employees" : "Show Employees"}
          </button>
          </div>
        </div>

     




      {
        showEmployees &&
        employees.map((emp) => {


          function deleteEmployee(id) {
            setEmployees(employees.filter((emp) => emp.id !== id));
          }

          return (
            <Employee
              key={emp.id}
              id={emp.id}
              name={emp.name}
              department={emp.department}
              onDelete={deleteEmployee}
            />
          );
        })
      }



      <Footer />
       </div>

    </div>
  )
}


export default App;